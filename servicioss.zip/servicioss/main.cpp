#include "mainwindow.h"
#include <QApplication>
#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include <QDebug>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("Registro de Internet");
    w.show();
    return a.exec();
        // Ruta fija donde se guardará el archivo
        QString filePath = "C:/contratacion/servicios/servicioss.pro";

        // Abrimos el archivo en modo escritura (WriteOnly)
        QFile file(filePath);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            qDebug() << "No se pudo abrir el archivo para escribir.";
            return -1;
        }

        QTextStream out(&file);
        out << "Este es un texto guardado desde Qt C++.\n";

        file.close();

        qDebug() << "Archivo guardado correctamente en:" << filePath;

        return 0;
}



